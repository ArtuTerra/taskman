<?php

return [
    'supports_credentials' => true,
    'allowed_origins' => ['*'],
    'allowed_headers' => ['*'],
    'allowed_methods' => ['*'],
];
